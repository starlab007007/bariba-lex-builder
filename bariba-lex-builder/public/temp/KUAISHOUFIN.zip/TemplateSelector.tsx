/**
 * TemplateSelector.tsx
 * Interface de sélection de templates avec catégories et previews
 * Version: 1.0.0
 */

import React, { useState, useMemo } from 'react';
import { KuaishouTemplateConfig, TemplateCategory } from '../types/KuaishouTypes';
import './TemplateSelector.css';

interface TemplateSelectorProps {
  templates: KuaishouTemplateConfig[];
  onSelect: (template: KuaishouTemplateConfig) => void;
  onBack?: () => void;
}

export const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  templates,
  onSelect,
  onBack
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'popularity' | 'rating' | 'recent'>('popularity');

  // Catégories uniques
  const categories = useMemo(() => {
    const cats = new Set<string>(['all']);
    templates.forEach(t => cats.add(t.category));
    return Array.from(cats);
  }, [templates]);

  // Templates filtrés
  const filteredTemplates = useMemo(() => {
    let filtered = templates;

    // Filtre par catégorie
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(t => t.category === selectedCategory);
    }

    // Filtre par recherche
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        t =>
          t.name.toLowerCase().includes(query) ||
          t.description.toLowerCase().includes(query) ||
          t.metadata.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Tri
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'popularity':
          return b.metadata.popularity - a.metadata.popularity;
        case 'rating':
          return b.metadata.rating - a.metadata.rating;
        case 'recent':
          return new Date(b.metadata.updatedAt).getTime() - new Date(a.metadata.updatedAt).getTime();
        default:
          return 0;
      }
    });

    return filtered;
  }, [templates, selectedCategory, searchQuery, sortBy]);

  return (
    <div className="template-selector">
      {/* Header */}
      <div className="selector-header">
        {onBack && (
          <button className="back-button" onClick={onBack}>
            ← Retour
          </button>
        )}
        <h1 className="selector-title">Choisis ton template</h1>
        <p className="selector-subtitle">{templates.length} templates disponibles</p>
      </div>

      {/* Search Bar */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Rechercher un template..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="search-input"
        />
        <span className="search-icon">🔍</span>
      </div>

      {/* Category Tabs */}
      <div className="category-tabs">
        {categories.map(cat => (
          <button
            key={cat}
            className={`category-tab ${selectedCategory === cat ? 'active' : ''}`}
            onClick={() => setSelectedCategory(cat)}
          >
            {getCategoryEmoji(cat)} {cat.charAt(0).toUpperCase() + cat.slice(1)}
          </button>
        ))}
      </div>

      {/* Sort Options */}
      <div className="sort-options">
        <label>Trier par:</label>
        <select value={sortBy} onChange={e => setSortBy(e.target.value as any)}>
          <option value="popularity">Popularité</option>
          <option value="rating">Note</option>
          <option value="recent">Plus récent</option>
        </select>
      </div>

      {/* Templates Grid */}
      <div className="templates-grid">
        {filteredTemplates.length > 0 ? (
          filteredTemplates.map(template => (
            <TemplateCard
              key={template.id}
              template={template}
              onClick={() => onSelect(template)}
            />
          ))
        ) : (
          <div className="no-results">
            <p>Aucun template trouvé 😕</p>
            <button onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}>
              Réinitialiser les filtres
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// ==========================================
// TEMPLATE CARD COMPONENT
// ==========================================

interface TemplateCardProps {
  template: KuaishouTemplateConfig;
  onClick: () => void;
}

const TemplateCard: React.FC<TemplateCardProps> = ({ template, onClick }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`template-card ${isHovered ? 'hovered' : ''}`}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Thumbnail / Preview */}
      <div className="card-thumbnail">
        {isHovered && template.metadata.previewVideo ? (
          <video
            src={template.metadata.previewVideo}
            autoPlay
            loop
            muted
            className="preview-video"
          />
        ) : (
          <img
            src={template.metadata.thumbnail}
            alt={template.name}
            className="preview-image"
          />
        )}

        {/* Overlay badges */}
        <div className="card-badges">
          <span className={`badge difficulty ${template.difficulty}`}>
            {template.difficulty === 'beginner' && '⭐'}
            {template.difficulty === 'intermediate' && '⭐⭐'}
            {template.difficulty === 'advanced' && '⭐⭐⭐'}
          </span>
          <span className="badge type">{getCategoryEmoji(template.category)}</span>
        </div>
      </div>

      {/* Card Info */}
      <div className="card-info">
        <h3 className="card-title">{template.name}</h3>
        <p className="card-description">{template.description}</p>

        <div className="card-meta">
          <div className="meta-item">
            <span className="meta-icon">⏱️</span>
            <span>{template.video.duration}s</span>
          </div>
          <div className="meta-item">
            <span className="meta-icon">⭐</span>
            <span>{template.metadata.rating.toFixed(1)}</span>
          </div>
          <div className="meta-item">
            <span className="meta-icon">🔥</span>
            <span>{formatNumber(template.metadata.usageCount)}</span>
          </div>
        </div>

        {/* Tags */}
        <div className="card-tags">
          {template.metadata.tags.slice(0, 3).map(tag => (
            <span key={tag} className="tag">
              {tag}
            </span>
          ))}
        </div>
      </div>

      {/* Hover effect */}
      {isHovered && (
        <div className="card-hover-overlay">
          <button className="use-template-btn">
            Utiliser ce template 🚀
          </button>
        </div>
      )}
    </div>
  );
};

// ==========================================
// HELPER FUNCTIONS
// ==========================================

function getCategoryEmoji(category: string): string {
  const emojis: Record<string, string> = {
    all: '🎬',
    dance: '💃',
    tutorial: '📚',
    story: '📖',
    challenge: '🏆',
    vlog: '🎥',
    comedy: '😂',
    beauty: '💄',
    food: '🍔',
    travel: '✈️',
    fitness: '💪'
  };

  return emojis[category] || '🎬';
}

function formatNumber(num: number): string {
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  } else if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K`;
  }
  return num.toString();
}

export default TemplateSelector;
