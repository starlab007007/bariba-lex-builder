# Kit DUNYA — réentraînement du traducteur à partir de v03

1. Kaggle > Datasets > New Dataset : déposer ce zip (nom : dunya-translate-kit).
2. Kaggle > Code > New Notebook > File > Import Notebook : notebook-kaggle.ipynb.
3. Input > Add Input : le dataset dunya-translate-kit.
4. Settings : Accelerator = GPU T4 x2, Internet = On.
5. Add-ons > Secrets : HF_TOKEN = token Hugging Face de type Write (case Attached cochée).
6. Save Version > Save & Run All (environ 4 h).
7. Résultat : onglet Output > comparaison.json (scores v03 / nouveau modèle) et dunya-translate-result.zip.
   Si le nouveau modèle bat v03, il est publié dans zimesongbian/byt5-bariba-fitila-v04 (privé).
