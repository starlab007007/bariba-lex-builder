// À intégrer dans src/components/tamtam/creator/AdvancedTemplateData.ts
// Remplacer l'entrée existante one_take_pro (lignes 664-682)

{
  id: 'one_take_pro',
  emoji: '🎬',
  label_fr: 'One-Take Pro Enhanced',
  label_ba: 'Gba kelen kↄrↄba',
  description_fr: 'Stabilisation + effets Kuaishou (calligraphie, particules, animations)',
  description_ba: 'Gba kelen kaa sↄ ni fɛɛnsira ye',
  family: 'grand_public',
  collection: null,
  inputs: [
    { type: 'video', minCount: 1, maxCount: 1 },
    { type: 'audio', minCount: 0, maxCount: 1, label: 'Musique pour beat sync' }
  ],
  supportedDurations: ['15s'],
  outputRatios: ['9:16'],
  features: {
    stabilization: true,
    autoEditing: true,
    kenBurns: true,
    beatSync: true,
    particles: true,
    calligraphy: true,
    animations: true
  },
  previewAnimation: 'spring-blur',
  color: 'from-red-500 via-orange-500 to-amber-500',
  voiceInstructions: [
    {
      step: 1,
      text_fr: 'Filme en marchant, même si ça tremble',
      text_ba: 'Ka gba kↄ, hali ni a bɔra',
      action: 'record_video'
    },
    {
      step: 2,
      text_fr: 'Ajoute une musique pour le beat sync (optionnel)',
      text_ba: 'Ka donkili fara a kan (ni i b\'a fɛ)',
      action: 'select_audio'
    },
    {
      step: 3,
      text_fr: 'L\'IA va stabiliser, animer et embellir tout',
      text_ba: 'IA bɛna a sabati ani ka a nↄgↄya',
      action: 'wait'
    }
  ],
  aiFeatures: [
    'Stabilisation vidéo automatique',
    'Recadrage intelligent',
    'Effet Ken Burns dynamique',
    'Particules et sparkles',
    'Calligraphie animée',
    'Beat sync avec audio',
    'Silhouette de cheval animée',
    'Phases intro/main/outro',
    'Color grading automatique'
  ]
}
