// ========================================
// CODE À AJOUTER DANS TemplateEngine.ts
// Nouvelles méthodes pour supporter One-Take Pro Enhanced
// ========================================

// ─────────────────────────────────────────────────────────────────
// 1. PARTICLE LAYER RENDERER
// Position : après renderTextLayer(), ligne ~650
// ─────────────────────────────────────────────────────────────────

private renderParticleLayer(
  layer: any,
  ctx: CanvasRenderingContext2D,
  now: number
): void {
  if (!layer.particles) return;

  const particles = layer.particles;
  const count = particles.count || 14;
  
  for (let i = 0; i < count; i++) {
    const seed = i * 1000;
    
    // Position aléatoire mais stable (based on seed)
    const xMin = particles.area?.x?.[0] ?? 8;
    const xMax = particles.area?.x?.[1] ?? 48;
    const yMin = particles.area?.y?.[0] ?? 10;
    const yMax = particles.area?.y?.[1] ?? 50;
    
    const x = xMin + (this.pseudoRandom(seed) * (xMax - xMin));
    const y = yMin + (this.pseudoRandom(seed + 100) * (yMax - yMin));
    
    // Taille
    const sizeMin = particles.size?.[0] ?? 2;
    const sizeMax = particles.size?.[1] ?? 5;
    const size = sizeMin + (this.pseudoRandom(seed + 200) * (sizeMax - sizeMin));
    
    // Animation pulse
    const durationMin = particles.duration?.[0] ?? 1.2;
    const durationMax = particles.duration?.[1] ?? 3.0;
    const duration = durationMin + (this.pseudoRandom(seed + 300) * (durationMax - durationMin));
    const delay = this.pseudoRandom(seed + 400) * 1.5;
    
    const phase = ((now + delay) % duration) / duration;
    const pulse = Math.sin(phase * Math.PI * 2);
    
    // Opacity animation [0.15, 0.7, 0.15]
    const opacity = 0.15 + 0.55 * Math.abs(pulse);
    
    // Scale animation [0.9, 1.25, 0.9]
    const scale = 0.9 + 0.35 * (0.5 + 0.5 * pulse);
    
    // Y float [0, -6, 0]
    const yOffset = -3 * pulse;
    
    // Dessiner la particule
    ctx.save();
    ctx.globalAlpha = opacity;
    
    const px = (x / 100) * this.canvas.width;
    const py = (y / 100) * this.canvas.height + yOffset;
    
    // Shadow
    if (particles.shadow) {
      ctx.shadowBlur = 10;
      ctx.shadowColor = particles.shadow;
    }
    
    ctx.fillStyle = particles.color || 'rgba(255,255,255,0.7)';
    ctx.beginPath();
    ctx.arc(px, py, size * scale, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();
  }
}

// Helper pour random stable
private pseudoRandom(seed: number): number {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

// ─────────────────────────────────────────────────────────────────
// 2. COMPOSITE LAYER RENDERER
// Position : après renderParticleLayer(), ligne ~720
// ─────────────────────────────────────────────────────────────────

private renderCompositeLayer(
  layer: any,
  ctx: CanvasRenderingContext2D,
  now: number
): void {
  if (!layer.children || layer.children.length === 0) return;

  ctx.save();
  
  // Résoudre la position du conteneur
  const pos = layer.position || {};
  const x = this.resolvePosition(pos.x, this.canvas.width);
  const y = this.resolvePosition(pos.y, this.canvas.height);
  
  ctx.translate(x, y);
  
  // Appliquer les animations du conteneur
  if (layer.animation) {
    this.applyAnimations(ctx, layer.animation, now, layer);
  }
  
  // Dessiner le container background si défini
  if (layer.container) {
    this.renderContainer(ctx, layer.container, layer.children);
  }
  
  // Rendre tous les enfants
  for (const child of layer.children) {
    ctx.save();
    
    // Position relative de l'enfant
    const childPos = child.position || {};
    const cx = this.resolvePosition(childPos.x, 0);
    const cy = this.resolvePosition(childPos.y, 0);
    ctx.translate(cx, cy);
    
    // Dessiner l'enfant selon son type
    this.renderChildLayer(child, ctx, now);
    
    ctx.restore();
  }
  
  ctx.restore();
}

private renderContainer(
  ctx: CanvasRenderingContext2D,
  container: any,
  children: any[]
): void {
  // Calculer les dimensions du container basé sur les enfants
  const padding = container.padding || [12, 16];
  const padY = padding[0];
  const padX = padding[1];
  
  // Dimensions approximatives (à améliorer selon les besoins)
  const width = 200; // ou calculer dynamiquement
  const height = 80;
  
  // Background
  if (container.background) {
    ctx.fillStyle = container.background;
    this.roundRect(ctx, -width/2 - padX, -height/2 - padY, width + padX*2, height + padY*2, container.borderRadius || 0);
    ctx.fill();
  }
  
  // Border
  if (container.border) {
    const borderParts = container.border.split(' ');
    ctx.strokeStyle = borderParts[borderParts.length - 1];
    ctx.lineWidth = parseInt(borderParts[0]);
    this.roundRect(ctx, -width/2 - padX, -height/2 - padY, width + padX*2, height + padY*2, container.borderRadius || 0);
    ctx.stroke();
  }
  
  // Backdrop blur (simulé avec shadow)
  if (container.backdropBlur) {
    ctx.shadowBlur = container.backdropBlur;
    ctx.shadowColor = 'rgba(0,0,0,0.1)';
  }
}

private renderChildLayer(
  child: any,
  ctx: CanvasRenderingContext2D,
  now: number
): void {
  switch (child.type) {
    case 'text_layer':
      this.renderTextLayer(child, ctx);
      break;
    case 'shape_layer':
      this.renderShapeLayer(child, ctx);
      break;
    default:
      console.warn(`Unsupported child layer type: ${child.type}`);
  }
}

private renderShapeLayer(layer: any, ctx: CanvasRenderingContext2D): void {
  ctx.save();
  
  // Blur
  if (layer.blur) {
    ctx.filter = `blur(${layer.blur}px)`;
  }
  
  ctx.fillStyle = layer.color || 'rgba(0,0,0,0.5)';
  
  const pos = layer.position || {};
  const x = this.resolvePosition(pos.x, 0);
  const y = this.resolvePosition(pos.y, 0);
  
  switch (layer.shape) {
    case 'circle':
      ctx.beginPath();
      ctx.arc(x, y, layer.size / 2, 0, Math.PI * 2);
      ctx.fill();
      break;
    case 'rect':
      ctx.fillRect(x - layer.size/2, y - layer.size/2, layer.size, layer.size);
      break;
  }
  
  ctx.restore();
}

private roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
): void {
  if (radius === 0) {
    ctx.rect(x, y, width, height);
    return;
  }
  
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.arcTo(x + width, y, x + width, y + radius, radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.arcTo(x + width, y + height, x + width - radius, y + height, radius);
  ctx.lineTo(x + radius, y + height);
  ctx.arcTo(x, y + height, x, y + height - radius, radius);
  ctx.lineTo(x, y + radius);
  ctx.arcTo(x, y, x + radius, y, radius);
  ctx.closePath();
}

// ─────────────────────────────────────────────────────────────────
// 3. SVG LAYER RENDERER
// Position : après renderCompositeLayer(), ligne ~850
// ─────────────────────────────────────────────────────────────────

private svgCache: Map<string, HTMLImageElement> = new Map();

private async renderSVGLayer(
  layer: any,
  ctx: CanvasRenderingContext2D,
  now: number
): Promise<void> {
  if (!layer.asset) return;

  const svgPath = `/templates/assets/svg/${layer.asset}`;
  
  // Charger ou récupérer du cache
  let img = this.svgCache.get(svgPath);
  if (!img) {
    img = await this.loadSVGImage(svgPath);
    this.svgCache.set(svgPath, img);
  }
  
  if (!img.complete) return;

  ctx.save();
  
  // Position de base
  const pos = layer.position || {};
  let x = this.resolvePosition(pos.x, this.canvas.width);
  let y = this.resolvePosition(pos.y, this.canvas.height);
  
  // Animation traverse (principale)
  if (layer.animation?.loop?.type === 'traverse') {
    const anim = layer.animation.loop;
    const duration = anim.duration || 10;
    const progress = (now % duration) / duration;
    
    const fromX = this.resolvePosition(anim.from?.x, this.canvas.width);
    const toX = this.resolvePosition(anim.to?.x, this.canvas.width);
    
    x = fromX + (toX - fromX) * progress;
  }
  
  ctx.translate(x, y);
  
  // Animation secondaire (float)
  if (layer.animation?.secondary?.type === 'float') {
    const floatAnim = layer.animation.secondary;
    const floatDuration = floatAnim.duration || 0.55;
    const floatPhase = (now / floatDuration) % 1.0;
    const floatY = (floatAnim.y?.[0] ?? -4) * Math.sin(floatPhase * Math.PI * 2);
    ctx.translate(0, floatY);
  }
  
  // Beat sync
  if (layer.beatSync?.enabled && this.audioEnergy > 0) {
    const scaleMin = layer.beatSync.scale?.[0] ?? 1.0;
    const scaleMax = layer.beatSync.scale?.[1] ?? 1.03;
    const scale = scaleMin + (scaleMax - scaleMin) * this.audioEnergy;
    ctx.scale(scale, scale);
  }
  
  // Shadow
  if (layer.shadow) {
    const shadowParts = layer.shadow.split(' ');
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = parseInt(shadowParts[0]);
    ctx.shadowBlur = parseInt(shadowParts[1]);
    ctx.shadowColor = shadowParts[2];
  }
  
  // Dessiner l'image SVG
  const width = layer.size?.width ?? 192;
  const height = layer.size?.height ?? 96;
  
  ctx.drawImage(img, -width / 2, -height / 2, width, height);
  
  ctx.restore();
}

private async loadSVGImage(path: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = path;
  });
}

// ─────────────────────────────────────────────────────────────────
// 4. GRADIENT LAYER RENDERER
// Position : après renderSVGLayer(), ligne ~950
// ─────────────────────────────────────────────────────────────────

private renderGradientLayer(
  layer: any,
  ctx: CanvasRenderingContext2D
): void {
  if (!layer.gradient) return;

  ctx.save();
  
  const gradient = layer.gradient;
  let grad: CanvasGradient;
  
  if (gradient.type === 'radial') {
    // Gradient radial
    const cx = (gradient.center?.[0] ?? 50) / 100 * this.canvas.width;
    const cy = (gradient.center?.[1] ?? 50) / 100 * this.canvas.height;
    const rx = (gradient.radius?.[0] ?? 60) / 100 * this.canvas.width;
    const ry = (gradient.radius?.[1] ?? 50) / 100 * this.canvas.height;
    const radius = Math.max(rx, ry);
    
    grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
  } else {
    // Gradient linéaire
    let x0 = 0, y0 = 0, x1 = 0, y1 = this.canvas.height;
    
    if (gradient.direction === 'to-bottom') {
      y1 = this.canvas.height;
    } else if (gradient.direction === 'to-top') {
      y0 = this.canvas.height;
      y1 = 0;
    }
    
    grad = ctx.createLinearGradient(x0, y0, x1, y1);
  }
  
  // Ajouter les color stops
  const colors = gradient.colors || [];
  colors.forEach((color: string, i: number) => {
    const stop = i / Math.max(1, colors.length - 1);
    grad.addColorStop(stop, color);
  });
  
  // Appliquer le blend mode
  if (layer.blend) {
    ctx.globalCompositeOperation = layer.blend as GlobalCompositeOperation;
  }
  
  // Beat sync pour opacity
  let opacity = 1.0;
  if (layer.beatSync?.enabled && this.audioEnergy > 0) {
    const opacityMin = layer.beatSync.opacity?.[0] ?? 0.12;
    const opacityMax = layer.beatSync.opacity?.[1] ?? 0.55;
    opacity = opacityMin + (opacityMax - opacityMin) * this.audioEnergy;
  }
  
  ctx.globalAlpha = opacity;
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  
  ctx.restore();
}

// ─────────────────────────────────────────────────────────────────
// 5. PROGRESS LAYER RENDERER
// Position : après renderGradientLayer(), ligne ~1020
// ─────────────────────────────────────────────────────────────────

private renderProgressLayer(
  layer: any,
  ctx: CanvasRenderingContext2D
): void {
  if (!this.templateDuration || !layer.style) return;

  const progress = this.currentTime / this.templateDuration;
  
  const pos = layer.position || {};
  const x = pos.x ?? 20;
  const y = this.canvas.height - (pos.y ?? 16);
  
  // Width (peut être "calc(100% - 40px)" ou un nombre)
  let width = this.canvas.width - 40;
  if (typeof pos.width === 'string') {
    // Parse calc() si présent
    const match = pos.width.match(/calc\(100% - (\d+)px\)/);
    if (match) {
      width = this.canvas.width - parseInt(match[1]);
    }
  } else if (typeof pos.width === 'number') {
    width = pos.width;
  }
  
  const height = layer.style.height ?? 6;
  const borderRadius = layer.style.borderRadius ?? 3;
  
  ctx.save();
  
  // Background
  ctx.fillStyle = layer.style.background || 'rgba(255,255,255,0.1)';
  this.roundRect(ctx, x, y, width, height, borderRadius);
  ctx.fill();
  
  // Fill (progress)
  ctx.fillStyle = layer.style.fill || 'rgba(255,255,255,0.7)';
  const fillWidth = width * Math.min(1, Math.max(0, progress));
  this.roundRect(ctx, x, y, fillWidth, height, borderRadius);
  ctx.fill();
  
  ctx.restore();
}

// ─────────────────────────────────────────────────────────────────
// 6. AUDIO ENERGY TRACKING
// Position : dans la classe TemplateEngine, ajouter ces propriétés
// ─────────────────────────────────────────────────────────────────

private audioEnergy: number = 0;

public setAudioEnergy(energy: number): void {
  this.audioEnergy = Math.max(0, Math.min(1, energy));
}

public getAudioEnergy(): number {
  return this.audioEnergy;
}

// ─────────────────────────────────────────────────────────────────
// 7. RÉSOLUTION DE POSITION (helper)
// Position : helpers, ligne ~1100
// ─────────────────────────────────────────────────────────────────

private resolvePosition(value: any, max: number): number {
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    if (value === 'center') return max / 2;
    if (value.endsWith('%')) {
      const percent = parseFloat(value);
      return (percent / 100) * max;
    }
    if (value.endsWith('px')) {
      return parseFloat(value);
    }
  }
  return 0;
}

// ─────────────────────────────────────────────────────────────────
// 8. MISE À JOUR DE renderFrameToCanvas()
// Position : méthode existante, ajouter les nouveaux types de layers
// ─────────────────────────────────────────────────────────────────

// Dans renderFrameToCanvas(), dans le switch des layer types, ajouter:

case 'particle_layer':
  this.renderParticleLayer(layer, ctx, this.currentTime);
  break;

case 'composite_layer':
  this.renderCompositeLayer(layer, ctx, this.currentTime);
  break;

case 'svg_layer':
  await this.renderSVGLayer(layer, ctx, this.currentTime);
  break;

case 'gradient_layer':
  this.renderGradientLayer(layer, ctx);
  break;

case 'progress_layer':
  this.renderProgressLayer(layer, ctx);
  break;

// ─────────────────────────────────────────────────────────────────
// 9. APPLY ANIMATIONS (helper pour composite layers)
// ─────────────────────────────────────────────────────────────────

private applyAnimations(
  ctx: CanvasRenderingContext2D,
  animation: any,
  now: number,
  layer: any
): void {
  const start = layer.start ?? 0;
  const end = layer.end ?? this.templateDuration;
  const localTime = now - start;
  
  // Animation IN
  if (animation.in && localTime < (animation.in.duration ?? 0.5)) {
    const progress = localTime / animation.in.duration;
    
    if (animation.in.from) {
      const { opacity, y, scale, blur } = animation.in.from;
      
      if (opacity !== undefined) {
        ctx.globalAlpha *= opacity + (1 - opacity) * progress;
      }
      if (y !== undefined) {
        ctx.translate(0, y * (1 - progress));
      }
      if (scale !== undefined) {
        const s = scale + (1 - scale) * progress;
        ctx.scale(s, s);
      }
      if (blur !== undefined) {
        ctx.filter = `blur(${blur * (1 - progress)}px)`;
      }
    }
  }
  
  // Animation LOOP
  if (animation.loop) {
    const loop = animation.loop;
    
    if (loop.type === 'float') {
      const duration = loop.duration ?? 1.1;
      const phase = (now / duration) % 1.0;
      const yOffset = (loop.y?.[0] ?? -3) * Math.sin(phase * Math.PI * 2);
      ctx.translate(0, yOffset);
    }
    
    if (loop.type === 'breathe') {
      const duration = loop.duration ?? 0.9;
      const phase = (now / duration) % 1.0;
      const pulse = Math.sin(phase * Math.PI * 2);
      
      const scaleMin = loop.scale?.[0] ?? 1.0;
      const scaleMax = loop.scale?.[1] ?? 1.03;
      const scale = scaleMin + (scaleMax - scaleMin) * (0.5 + 0.5 * pulse);
      ctx.scale(scale, scale);
      
      if (loop.y) {
        const yOffset = (loop.y[0] + loop.y[1]) / 2 + ((loop.y[1] - loop.y[0]) / 2) * pulse;
        ctx.translate(0, yOffset);
      }
    }
  }
}

// ─────────────────────────────────────────────────────────────────
// FIN DU CODE TEMPLATEENGINE.TS
// ─────────────────────────────────────────────────────────────────
