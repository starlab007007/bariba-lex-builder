// ========================================
// CODE À AJOUTER DANS FullscreenCreator.tsx
// Audio Analyser pour Beat Sync
// ========================================

// ─────────────────────────────────────────────────────────────────
// 1. AJOUTER CES REFS DANS LE COMPOSANT (avec les autres refs)
// Position : après streamRef, videoRef, etc. (ligne ~200)
// ─────────────────────────────────────────────────────────────────

const audioContextRef = useRef<AudioContext | null>(null);
const audioAnalyserRef = useRef<AnalyserNode | null>(null);
const audioSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
const audioRafRef = useRef<number>(0);

// ─────────────────────────────────────────────────────────────────
// 2. FONCTION D'INITIALISATION DE L'ANALYSEUR AUDIO
// Position : dans le corps du composant, avec les autres fonctions
// ─────────────────────────────────────────────────────────────────

const setupAudioAnalyser = useCallback((audioElement: HTMLAudioElement) => {
  // Cleanup previous analyser
  cleanupAudioAnalyser();

  try {
    // Créer le contexte audio
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    audioContextRef.current = audioCtx;

    // Créer l'analyseur
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 1024;
    analyser.smoothingTimeConstant = 0.8;
    audioAnalyserRef.current = analyser;

    // Connecter la source audio
    const source = audioCtx.createMediaElementSource(audioElement);
    audioSourceRef.current = source;
    
    source.connect(analyser);
    analyser.connect(audioCtx.destination);

    // Buffer pour les données de fréquence
    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    // Fonction d'analyse en boucle
    const analyseAudio = () => {
      if (!analyser) return;

      analyser.getByteFrequencyData(dataArray);

      // Analyse des fréquences low-mid (punch, basse)
      // 0.02 - 0.22 du spectre = ~20-2200Hz à 44.1kHz
      const n = dataArray.length;
      const startIdx = Math.floor(n * 0.02);
      const endIdx = Math.floor(n * 0.22);

      let sum = 0;
      for (let i = startIdx; i < endIdx; i++) {
        sum += dataArray[i];
      }

      const avg = sum / Math.max(1, endIdx - startIdx);

      // Normalisation : 0-255 → 0-1
      // On considère 25 comme le bruit de fond, 155 comme max
      const normalized = Math.max(0, Math.min(1, (avg - 25) / 130));

      // Envoyer l'énergie au K-Engine
      if (kEngineRef.current) {
        kEngineRef.current.setAudioEnergy(normalized);
      }

      // Continuer l'analyse
      audioRafRef.current = requestAnimationFrame(analyseAudio);
    };

    // Démarrer l'analyse
    audioRafRef.current = requestAnimationFrame(analyseAudio);

    console.log('✅ Audio analyser initialized for beat sync');
  } catch (error) {
    console.error('❌ Failed to initialize audio analyser:', error);
  }
}, []);

const cleanupAudioAnalyser = useCallback(() => {
  // Annuler la RAF
  if (audioRafRef.current) {
    cancelAnimationFrame(audioRafRef.current);
    audioRafRef.current = 0;
  }

  // Déconnecter les nodes
  try {
    if (audioSourceRef.current) {
      audioSourceRef.current.disconnect();
      audioSourceRef.current = null;
    }
  } catch (e) {
    // Peut déjà être déconnecté
  }

  try {
    if (audioAnalyserRef.current) {
      audioAnalyserRef.current.disconnect();
      audioAnalyserRef.current = null;
    }
  } catch (e) {
    // Peut déjà être déconnecté
  }

  // Fermer le contexte
  try {
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
  } catch (e) {
    // Peut déjà être fermé
  }

  // Reset l'énergie dans K-Engine
  if (kEngineRef.current) {
    kEngineRef.current.setAudioEnergy(0);
  }
}, []);

// ─────────────────────────────────────────────────────────────────
// 3. CLEANUP AU DÉMONTAGE DU COMPOSANT
// Position : dans useEffect de cleanup (ligne ~300 ou créer un nouveau)
// ─────────────────────────────────────────────────────────────────

useEffect(() => {
  // Cleanup à la fermeture du composant
  return () => {
    cleanupAudioAnalyser();
  };
}, [cleanupAudioAnalyser]);

// ─────────────────────────────────────────────────────────────────
// 4. INTÉGRATION DANS LE GOLDEN PATH (chargement template)
// Position : dans la section one_take_pro du Golden Path (ligne ~1700)
// ─────────────────────────────────────────────────────────────────

if (templateId === 'one_take_pro') {
  // ... code existant (fetch manifest, loadTemplate, etc.) ...

  // ✨ NOUVEAU CODE ICI ✨
  
  // Vérifier si le slot audio_beat est rempli
  const audioSlot = manifestJson.slots.find((s: any) => s.id === 'audio_beat');
  
  if (audioSlot) {
    // Attendre que le média audio soit lié au slot
    const checkAudioBinding = setInterval(() => {
      const audioMedia = kEngine.getSlotMedia(audioSlot.id);
      
      if (audioMedia) {
        clearInterval(checkAudioBinding);
        
        // Créer un élément audio pour l'analyse
        const audioElement = new Audio();
        
        // Charger le média audio
        if (audioMedia instanceof Blob || audioMedia instanceof File) {
          const url = URL.createObjectURL(audioMedia);
          audioElement.src = url;
          
          // Cleanup de l'URL à la fin
          audioElement.addEventListener('loadeddata', () => {
            URL.revokeObjectURL(url);
          });
        } else if (typeof audioMedia === 'string') {
          audioElement.src = audioMedia;
        }
        
        // Configuration audio
        audioElement.loop = true;
        audioElement.volume = 0.5; // Volume modéré
        
        // Initialiser l'analyseur quand l'audio est prêt
        audioElement.addEventListener('canplay', () => {
          setupAudioAnalyser(audioElement);
          audioElement.play().catch(err => {
            console.warn('Audio autoplay blocked:', err);
          });
        }, { once: true });
        
        audioElement.load();
        
        console.log('🎵 Audio beat sync enabled for one_take_pro');
      }
    }, 100);
    
    // Timeout après 5 secondes si pas de média audio
    setTimeout(() => {
      clearInterval(checkAudioBinding);
    }, 5000);
  }
}

// ─────────────────────────────────────────────────────────────────
// 5. ALTERNATIVE : BIND AUDIO DIRECTEMENT DEPUIS SLOT PICKER
// Position : dans TemplateSlotPicker.tsx ou dans le handler de bindUserMedia
// ─────────────────────────────────────────────────────────────────

// Dans le callback après bindUserMedia pour un slot audio:

const handleAudioBind = useCallback((slotId: string, audioFile: File | Blob) => {
  // Bind au K-Engine
  kEngine.bindUserMedia(slotId, audioFile);
  
  // Si c'est le slot audio_beat, initialiser l'analyseur
  if (slotId === 'audio_beat' && audioFile) {
    const audioElement = new Audio();
    const url = URL.createObjectURL(audioFile);
    audioElement.src = url;
    audioElement.loop = true;
    audioElement.volume = 0.5;
    
    audioElement.addEventListener('canplay', () => {
      setupAudioAnalyser(audioElement);
      audioElement.play().catch(err => {
        console.warn('Audio autoplay blocked:', err);
        // Créer un bouton play pour l'utilisateur
        showAudioPlayButton(audioElement);
      });
    }, { once: true });
    
    audioElement.load();
  }
}, [setupAudioAnalyser]);

// ─────────────────────────────────────────────────────────────────
// 6. BOUTON PLAY POUR CONTOURNER L'AUTOPLAY BLOCK
// Position : helper function dans le composant
// ─────────────────────────────────────────────────────────────────

const showAudioPlayButton = (audioElement: HTMLAudioElement) => {
  // Afficher un bouton temporaire pour démarrer l'audio
  // (l'autoplay peut être bloqué par le navigateur)
  
  const button = document.createElement('button');
  button.textContent = '🎵 Activer le beat sync';
  button.className = 'fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 bg-white/10 backdrop-blur-md rounded-full text-white font-bold border border-white/20 hover:bg-white/20 transition-all';
  
  button.onclick = () => {
    audioElement.play().then(() => {
      button.remove();
      setupAudioAnalyser(audioElement);
      console.log('🎵 Audio beat sync activated by user interaction');
    }).catch(err => {
      console.error('Failed to play audio:', err);
    });
  };
  
  document.body.appendChild(button);
  
  // Retirer le bouton après 10 secondes
  setTimeout(() => {
    button.remove();
  }, 10000);
};

// ─────────────────────────────────────────────────────────────────
// 7. VISUALISATION DEBUG (optionnel)
// Position : composant React pour afficher l'énergie audio
// ─────────────────────────────────────────────────────────────────

const AudioEnergyDebug = () => {
  const [energy, setEnergy] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      if (kEngineRef.current) {
        const currentEnergy = kEngineRef.current.getAudioEnergy();
        setEnergy(currentEnergy);
      }
    }, 50); // 20 FPS
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="fixed top-4 right-4 z-50 bg-black/80 backdrop-blur-md rounded-lg p-3 text-white text-xs">
      <div className="font-bold mb-1">🎵 Beat Sync</div>
      <div className="flex items-center gap-2">
        <div className="w-32 h-2 bg-white/20 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-100"
            style={{ width: `${energy * 100}%` }}
          />
        </div>
        <span className="font-mono">{Math.round(energy * 100)}%</span>
      </div>
    </div>
  );
};

// Dans le JSX du composant principal (pour debug):
{process.env.NODE_ENV === 'development' && <AudioEnergyDebug />}

// ─────────────────────────────────────────────────────────────────
// 8. TYPE DEFINITIONS (à ajouter dans les types)
// Position : dans le fichier de types ou au début du fichier
// ─────────────────────────────────────────────────────────────────

interface AudioAnalyserConfig {
  fftSize: number;
  smoothingTimeConstant: number;
  minDecibels: number;
  maxDecibels: number;
}

interface BeatSyncMetrics {
  energy: number;      // 0-1
  timestamp: number;   // Date.now()
  frequency: number;   // Hz
  tempo: number;       // BPM (si détectable)
}

// ─────────────────────────────────────────────────────────────────
// NOTES D'IMPLÉMENTATION
// ─────────────────────────────────────────────────────────────────

/**
 * IMPORTANT : Autoplay Policy
 * 
 * Les navigateurs bloquent souvent l'autoplay des médias audio.
 * Solutions :
 * 
 * 1. Attendre une interaction utilisateur (clic, touch)
 * 2. Afficher un bouton "Play" explicite
 * 3. Utiliser l'API Web Audio après un geste utilisateur
 * 
 * Le code ci-dessus inclut une fallback avec showAudioPlayButton()
 * qui affiche un bouton si l'autoplay est bloqué.
 */

/**
 * OPTIMISATION : Performance
 * 
 * L'analyse audio en temps réel peut être coûteuse.
 * Optimisations appliquées :
 * 
 * 1. smoothingTimeConstant: 0.8 (lisse les variations)
 * 2. fftSize: 1024 (équilibre qualité/perf)
 * 3. Analyse seulement 20% du spectre (low-mid)
 * 4. Normalisation simple (pas de FFT complexe)
 * 
 * Sur mobile, considérez réduire fftSize à 512 ou 256.
 */

/**
 * TROUBLESHOOTING
 * 
 * Si le beat sync ne fonctionne pas :
 * 
 * 1. Vérifier la console pour les erreurs Web Audio
 * 2. Tester avec AudioEnergyDebug activé
 * 3. Vérifier que audioElement.play() réussit
 * 4. Vérifier que kEngine.setAudioEnergy() est appelé
 * 5. Vérifier que les layers ont beatSync.enabled: true
 */

// ─────────────────────────────────────────────────────────────────
// FIN DU CODE FULLSCREENCREATOR.TSX
// ─────────────────────────────────────────────────────────────────
