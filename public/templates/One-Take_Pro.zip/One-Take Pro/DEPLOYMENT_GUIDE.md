# Guide de Déploiement - One-Take Pro Enhanced

## 📁 Structure des Fichiers à Créer

```
public/
├── templates/
│   ├── manifests/
│   │   └── one_take_pro.json          # Remplacer avec one_take_pro_enhanced.json
│   ├── packs/
│   │   └── textStyles/
│   │       ├── year_hero.style.json
│   │       ├── message_main.style.json
│   │       ├── message_sub.style.json
│   │       ├── calligraphy_main.style.json
│   │       ├── calligraphy_sub.style.json
│   │       ├── outro_main.style.json
│   │       ├── outro_sub.style.json
│   │       └── template_label.style.json
│   └── assets/
│       └── svg/
│           └── horse_silhouette.svg

src/
└── components/
    └── tamtam/
        └── creator/
            └── AdvancedTemplateData.ts  # Mettre à jour l'entrée one_take_pro
```

## 🚀 Étapes d'Intégration

### 1. Copier les fichiers JSON
```bash
# Manifest principal
cp one_take_pro_enhanced.json public/templates/manifests/one_take_pro.json

# Styles de texte
cp year_hero.style.json public/templates/packs/textStyles/
cp message_main.style.json public/templates/packs/textStyles/
cp message_sub.style.json public/templates/packs/textStyles/
cp calligraphy_main.style.json public/templates/packs/textStyles/
cp calligraphy_sub.style.json public/templates/packs/textStyles/
cp outro_main.style.json public/templates/packs/textStyles/
cp outro_sub.style.json public/templates/packs/textStyles/
cp template_label.style.json public/templates/packs/textStyles/

# SVG du cheval
mkdir -p public/templates/assets/svg
cp horse_silhouette.svg public/templates/assets/svg/
```

### 2. Mettre à jour AdvancedTemplateData.ts

Dans `src/components/tamtam/creator/AdvancedTemplateData.ts`, remplacer l'entrée `one_take_pro` (lignes 664-682) avec le contenu de `AdvancedTemplateData_one_take_pro.ts`.

### 3. Mettre à jour l'index des templates

Dans `public/templates/index.json`, modifier l'entrée one_take_pro :

```json
{
  "id": "one_take_pro",
  "name": "One Take Pro Enhanced",
  "durationSec": 15,
  "ratio": "9:16",
  "manifest": "manifests/one_take_pro.json",
  "tags": ["live", "authentic", "kuaishou", "animated", "sparkles", "calligraphy"],
  "family": "grand_public"
}
```

## 🎨 Nouvelles Fonctionnalités Ajoutées

### Timeline Enrichie (15 secondes)
- **0s - 1.6s** : Phase INTRO
  - Apparition du texte "2026" + messages avec blur-fade
  - Sparkles actifs
  - InkMark calligraphie visible
  
- **1.6s - 12.8s** : Phase MAIN
  - Cheval traverse l'écran (loop)
  - Textes flottent avec animation
  - Beat sync actif si musique
  - Ken Burns sur le background
  
- **12.8s - 15s** : Phase OUTRO
  - Carte "Prêt à publier ?" avec animation breathe
  - Fade out progressif

### Layers Ajoutés
1. **Gradients de chaleur** (warm glow + vignette)
2. **Sparkles particles** (16 particules animées)
3. **InkMark badge** (calligraphie + splashes d'encre)
4. **Textes temporisés** (year + messages avec phases)
5. **Horse silhouette** (traverse en loop avec float)
6. **Beat glow overlay** (synchronisé avec audio)
7. **Progress bar** + label template

### Effets Visuels
- **Ken Burns** : zoom 1.0 → 1.08 + pan ±6px
- **Beat Sync** : scale, glow, opacity synchronisés avec audio
- **Particles** : pulse-float avec shadows
- **Animations** : blur-fade, spring, breathe, traverse, float

## 🔧 Modifications du K-Engine Nécessaires

### Dans `TemplateEngine.ts`, ajouter le support pour :

#### 1. Particle Layer (lignes ~650)
```typescript
private renderParticleLayer(layer: any, ctx: CanvasRenderingContext2D) {
  const particles = layer.particles;
  const now = this.currentTime;
  
  for (let i = 0; i < particles.count; i++) {
    const seed = i * 1000;
    const x = this.lerp(particles.area.x[0], particles.area.x[1], this.noise(seed, now));
    const y = this.lerp(particles.area.y[0], particles.area.y[1], this.noise(seed + 100, now));
    const size = this.lerp(particles.size[0], particles.size[1], this.noise(seed + 200, now));
    
    // Animation pulse-float
    const phase = (now + seed * 0.001) % particles.duration[1];
    const opacity = 0.15 + 0.55 * Math.sin((phase / particles.duration[1]) * Math.PI * 2);
    
    ctx.save();
    ctx.globalAlpha = opacity;
    ctx.fillStyle = particles.color;
    ctx.shadowBlur = 10;
    ctx.shadowColor = particles.shadow;
    ctx.beginPath();
    ctx.arc(
      (x / 100) * this.canvas.width,
      (y / 100) * this.canvas.height,
      size,
      0,
      Math.PI * 2
    );
    ctx.fill();
    ctx.restore();
  }
}
```

#### 2. Composite Layer (lignes ~700)
```typescript
private renderCompositeLayer(layer: any, ctx: CanvasRenderingContext2D) {
  ctx.save();
  
  // Position du conteneur
  const x = this.resolvePosition(layer.position.x, this.canvas.width);
  const y = this.resolvePosition(layer.position.y, this.canvas.height);
  
  ctx.translate(x, y);
  
  // Rendu des enfants
  for (const child of layer.children) {
    this.renderLayer(child, ctx);
  }
  
  // Container style (background, border, etc.)
  if (layer.container) {
    this.applyContainerStyle(ctx, layer.container);
  }
  
  ctx.restore();
}
```

#### 3. SVG Layer (lignes ~750)
```typescript
private async renderSVGLayer(layer: any, ctx: CanvasRenderingContext2D) {
  const svgPath = `/templates/assets/svg/${layer.asset}`;
  const img = await this.loadImage(svgPath);
  
  const x = this.resolvePosition(layer.position.x, this.canvas.width);
  const y = this.resolvePosition(layer.position.y, this.canvas.height);
  
  ctx.save();
  
  // Animation traverse
  if (layer.animation?.loop?.type === 'traverse') {
    const anim = layer.animation.loop;
    const progress = (this.currentTime % anim.duration) / anim.duration;
    const fromX = this.resolvePosition(anim.from.x, this.canvas.width);
    const toX = this.resolvePosition(anim.to.x, this.canvas.width);
    const animX = fromX + (toX - fromX) * progress;
    ctx.translate(animX, y);
  } else {
    ctx.translate(x, y);
  }
  
  // Secondary animation (float)
  if (layer.animation?.secondary?.type === 'float') {
    const floatY = Math.sin((this.currentTime / 0.55) * Math.PI * 2) * 4;
    ctx.translate(0, floatY);
  }
  
  // Beat sync
  if (layer.beatSync?.enabled && this.audioEnergy > 0) {
    const scale = this.lerp(1.0, 1.03, this.audioEnergy);
    ctx.scale(scale, scale);
  }
  
  // Shadow
  if (layer.shadow) {
    ctx.shadowBlur = 40;
    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowOffsetY = 18;
  }
  
  ctx.drawImage(img, -layer.size.width / 2, -layer.size.height / 2, layer.size.width, layer.size.height);
  ctx.restore();
}
```

#### 4. Progress Layer (lignes ~800)
```typescript
private renderProgressLayer(layer: any, ctx: CanvasRenderingContext2D) {
  const progress = this.currentTime / this.templateDuration;
  
  const x = layer.position.x;
  const y = this.canvas.height - layer.position.y;
  const width = this.canvas.width - (layer.position.x * 2);
  
  ctx.save();
  
  // Background
  ctx.fillStyle = layer.style.background;
  ctx.fillRect(x, y, width, layer.style.height);
  
  // Fill
  ctx.fillStyle = layer.style.fill;
  ctx.fillRect(x, y, width * progress, layer.style.height);
  
  ctx.restore();
}
```

## 🎵 Beat Sync Integration

Dans `FullscreenCreator.tsx`, ajouter l'analyse audio :

```typescript
// Après le chargement du template (lignes ~1700)
if (templateId === 'one_take_pro') {
  // ... existing code ...
  
  // Setup audio analyser si audio_beat slot est rempli
  const audioSlot = manifestJson.slots.find(s => s.id === 'audio_beat');
  if (audioSlot && kEngine.getSlotMedia(audioSlot.id)) {
    setupAudioAnalyser(audioSlot.id);
  }
}

function setupAudioAnalyser(slotId: string) {
  const audioEl = kEngine.getAudioElement(slotId);
  if (!audioEl) return;
  
  const audioCtx = new AudioContext();
  const analyser = audioCtx.createAnalyser();
  analyser.fftSize = 1024;
  
  const source = audioCtx.createMediaElementSource(audioEl);
  source.connect(analyser);
  analyser.connect(audioCtx.destination);
  
  const dataArray = new Uint8Array(analyser.frequencyBinCount);
  
  const tick = () => {
    analyser.getByteFrequencyData(dataArray);
    
    // Low-mid energy (0.02 - 0.22)
    const start = Math.floor(dataArray.length * 0.02);
    const end = Math.floor(dataArray.length * 0.22);
    let sum = 0;
    for (let i = start; i < end; i++) sum += dataArray[i];
    const avg = sum / (end - start);
    
    const energy = Math.max(0, Math.min(1, (avg - 25) / 130));
    kEngine.setAudioEnergy(energy);
    
    requestAnimationFrame(tick);
  };
  
  tick();
}
```

## ✅ Checklist de Validation

- [ ] Tous les fichiers JSON sont dans les bons dossiers
- [ ] Le SVG du cheval s'affiche correctement
- [ ] Les styles de texte sont chargés (pas d'erreur 404)
- [ ] L'animation traverse du cheval fonctionne
- [ ] Les sparkles apparaissent en haut-gauche
- [ ] Le beat sync fonctionne avec audio
- [ ] Les phases intro/main/outro se déclenchent aux bons timings
- [ ] La progress bar se remplit correctement
- [ ] L'effet Ken Burns est visible sur le background
- [ ] Le drawer affiche bien "One-Take Pro Enhanced"

## 🐛 Debugging

Si un élément ne s'affiche pas :
1. Vérifier la console pour les erreurs 404
2. Vérifier que le manifest est bien chargé : `console.log(kEngine.manifest)`
3. Vérifier les timings des layers : `console.log(kEngine.currentTime)`
4. Activer le mode debug dans K-Engine : `kEngine.setDebug(true)`

## 🎯 Résultat Attendu

Un template de 15 secondes avec :
- Background vidéo stabilisé avec Ken Burns
- Calligraphie animée en haut-gauche
- Sparkles scintillants
- Texte "2026" + messages avec transitions fluides
- Cheval qui traverse l'écran en boucle
- Beat sync subtil sur tous les éléments
- Progress bar en bas
- Transition intro → main → outro
