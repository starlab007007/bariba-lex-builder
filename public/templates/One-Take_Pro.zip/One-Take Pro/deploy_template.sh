#!/bin/bash

# ========================================
# Script de Déploiement Automatique
# One-Take Pro Enhanced Template
# ========================================

set -e  # Exit on error

echo "🎬 Déploiement du template One-Take Pro Enhanced..."
echo ""

# Couleurs pour les messages
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Vérifier qu'on est dans le bon répertoire
if [ ! -d "public" ] || [ ! -d "src" ]; then
  echo "❌ Erreur: Ce script doit être exécuté à la racine du projet TamTam"
  exit 1
fi

echo "${BLUE}📁 Création des dossiers nécessaires...${NC}"
mkdir -p public/templates/manifests
mkdir -p public/templates/packs/textStyles
mkdir -p public/templates/assets/svg

echo ""
echo "${BLUE}📄 Copie du manifest principal...${NC}"
if [ -f "one_take_pro_enhanced.json" ]; then
  cp one_take_pro_enhanced.json public/templates/manifests/one_take_pro.json
  echo "${GREEN}✓ Manifest copié${NC}"
else
  echo "${YELLOW}⚠ Fichier one_take_pro_enhanced.json non trouvé${NC}"
fi

echo ""
echo "${BLUE}🎨 Copie des styles de texte...${NC}"
styles=(
  "year_hero"
  "message_main"
  "message_sub"
  "calligraphy_main"
  "calligraphy_sub"
  "outro_main"
  "outro_sub"
  "template_label"
)

for style in "${styles[@]}"; do
  if [ -f "${style}.style.json" ]; then
    cp "${style}.style.json" public/templates/packs/textStyles/
    echo "${GREEN}✓ ${style}.style.json copié${NC}"
  else
    echo "${YELLOW}⚠ ${style}.style.json non trouvé${NC}"
  fi
done

echo ""
echo "${BLUE}🐴 Copie du SVG du cheval...${NC}"
if [ -f "horse_silhouette.svg" ]; then
  cp horse_silhouette.svg public/templates/assets/svg/
  echo "${GREEN}✓ horse_silhouette.svg copié${NC}"
else
  echo "${YELLOW}⚠ horse_silhouette.svg non trouvé${NC}"
fi

echo ""
echo "${BLUE}📋 Mise à jour de l'index des templates...${NC}"

# Backup de l'index existant
if [ -f "public/templates/index.json" ]; then
  cp public/templates/index.json public/templates/index.json.backup
  echo "${GREEN}✓ Backup créé : index.json.backup${NC}"
fi

# Mise à jour de l'entrée one_take_pro dans l'index
# (À adapter selon votre structure JSON exacte)
cat > /tmp/one_take_pro_index_entry.json << 'EOF'
{
  "id": "one_take_pro",
  "name": "One Take Pro Enhanced",
  "durationSec": 15,
  "ratio": "9:16",
  "manifest": "manifests/one_take_pro.json",
  "tags": ["live", "authentic", "kuaishou", "animated", "sparkles", "calligraphy"],
  "family": "grand_public"
}
EOF

echo "${GREEN}✓ Entrée d'index créée${NC}"
echo "${YELLOW}⚠ Veuillez mettre à jour manuellement public/templates/index.json${NC}"
echo "${YELLOW}  avec le contenu de /tmp/one_take_pro_index_entry.json${NC}"

echo ""
echo "${BLUE}⚙️ Mise à jour de AdvancedTemplateData.ts...${NC}"

if [ -f "AdvancedTemplateData_one_take_pro.ts" ]; then
  echo "${YELLOW}⚠ Veuillez copier manuellement le contenu de AdvancedTemplateData_one_take_pro.ts${NC}"
  echo "${YELLOW}  dans src/components/tamtam/creator/AdvancedTemplateData.ts${NC}"
  echo "${YELLOW}  (remplacer l'entrée one_take_pro existante, lignes 664-682)${NC}"
else
  echo "${YELLOW}⚠ AdvancedTemplateData_one_take_pro.ts non trouvé${NC}"
fi

echo ""
echo "${GREEN}✅ Déploiement terminé !${NC}"
echo ""
echo "📝 Actions manuelles restantes :"
echo "  1. Mettre à jour public/templates/index.json"
echo "  2. Mettre à jour src/components/tamtam/creator/AdvancedTemplateData.ts"
echo "  3. Implémenter les nouveaux types de layers dans TemplateEngine.ts :"
echo "     - particle_layer"
echo "     - composite_layer"
echo "     - svg_layer"
echo "     - progress_layer"
echo "  4. Ajouter le beat sync audio analyser dans FullscreenCreator.tsx"
echo ""
echo "📚 Consultez DEPLOYMENT_GUIDE.md pour les détails d'implémentation"
echo ""

# Afficher un résumé des fichiers copiés
echo "📊 Résumé des fichiers :"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Manifests    : $(ls -1 public/templates/manifests/*.json 2>/dev/null | wc -l) fichier(s)"
echo "Styles       : $(ls -1 public/templates/packs/textStyles/*.json 2>/dev/null | wc -l) fichier(s)"
echo "Assets SVG   : $(ls -1 public/templates/assets/svg/*.svg 2>/dev/null | wc -l) fichier(s)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Vérifier que tous les fichiers critiques sont présents
echo "${BLUE}🔍 Vérification de l'intégrité...${NC}"

critical_files=(
  "public/templates/manifests/one_take_pro.json"
  "public/templates/packs/textStyles/year_hero.style.json"
  "public/templates/assets/svg/horse_silhouette.svg"
)

all_good=true
for file in "${critical_files[@]}"; do
  if [ -f "$file" ]; then
    echo "${GREEN}✓ $file${NC}"
  else
    echo "${YELLOW}✗ $file MANQUANT${NC}"
    all_good=false
  fi
done

echo ""
if [ "$all_good" = true ]; then
  echo "${GREEN}🎉 Tous les fichiers critiques sont en place !${NC}"
else
  echo "${YELLOW}⚠ Certains fichiers sont manquants. Consultez les messages ci-dessus.${NC}"
fi

echo ""
echo "🚀 Prochaines étapes :"
echo "  1. npm run dev (ou votre commande de dev)"
echo "  2. Ouvrir le Creator"
echo "  3. Sélectionner 'One-Take Pro Enhanced'"
echo "  4. Filmer une vidéo"
echo "  5. (Optionnel) Ajouter une musique pour le beat sync"
echo "  6. Voir la magie opérer ! ✨"
echo ""
