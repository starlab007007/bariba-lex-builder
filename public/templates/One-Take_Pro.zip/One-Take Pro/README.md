# 🎬 One-Take Pro Enhanced - Template Complet

> Template vidéo 15 secondes avec stabilisation, effets Kuaishou, particules, calligraphie, cheval animé et beat sync audio.

## 📋 Table des Matières

1. [Vue d'Ensemble](#vue-densemble)
2. [Fichiers Générés](#fichiers-générés)
3. [Installation Rapide](#installation-rapide)
4. [Architecture Détaillée](#architecture-détaillée)
5. [Nouvelles Fonctionnalités](#nouvelles-fonctionnalités)
6. [Implémentation Technique](#implémentation-technique)
7. [Troubleshooting](#troubleshooting)

---

## 🎯 Vue d'Ensemble

### Durée : 15 secondes
### Ratio : 9:16 (vertical)
### Phases : Intro (0-1.6s) → Main (1.6-12.8s) → Outro (12.8-15s)

### Features Principales

✅ **Stabilisation vidéo** intelligente  
✅ **Effet Ken Burns** (zoom + pan dynamique)  
✅ **Sparkles particles** (16 particules scintillantes)  
✅ **Calligraphie animée** (badge haut-gauche avec ink splashes)  
✅ **Cheval silhouette** (traverse l'écran en boucle)  
✅ **Beat sync audio** (tous les éléments respirent avec la musique)  
✅ **Phases temporisées** (intro/main/outro avec transitions fluides)  
✅ **Progress bar** animée  
✅ **Textes stylisés** (year + messages avec contours et shadows)  

---

## 📦 Fichiers Générés

```
📁 Fichiers du Template
├── one_take_pro_enhanced.json          # Manifest principal
├── horse_silhouette.svg                # SVG du cheval
├── year_hero.style.json                # Style texte "2026"
├── message_main.style.json             # Style messages principaux
├── message_sub.style.json              # Style sous-messages
├── calligraphy_main.style.json         # Style calligraphie principale
├── calligraphy_sub.style.json          # Style sous-calligraphie
├── outro_main.style.json               # Style texte outro principal
├── outro_sub.style.json                # Style texte outro secondaire
├── template_label.style.json           # Style label template
│
📁 Code d'Intégration
├── AdvancedTemplateData_one_take_pro.ts    # Données UI drawer
├── TemplateEngine_additions.ts             # Nouveaux renderers K-Engine
├── FullscreenCreator_audio_analyser.tsx    # Beat sync audio
│
📁 Documentation
├── DEPLOYMENT_GUIDE.md                 # Guide de déploiement complet
├── TIMELINE_VISUAL.txt                 # Schéma visuel de la timeline
├── deploy_template.sh                  # Script bash automatique
└── README.md                           # Ce fichier
```

---

## 🚀 Installation Rapide

### Option 1 : Script Automatique

```bash
# 1. Rendre le script exécutable
chmod +x deploy_template.sh

# 2. Exécuter le déploiement
./deploy_template.sh

# 3. Suivre les instructions pour les actions manuelles
```

### Option 2 : Manuel

```bash
# 1. Copier le manifest
cp one_take_pro_enhanced.json public/templates/manifests/one_take_pro.json

# 2. Copier les styles
cp *.style.json public/templates/packs/textStyles/

# 3. Copier le SVG
mkdir -p public/templates/assets/svg
cp horse_silhouette.svg public/templates/assets/svg/

# 4. Mettre à jour AdvancedTemplateData.ts
# Remplacer l'entrée one_take_pro (lignes 664-682)

# 5. Ajouter le code dans TemplateEngine.ts
# Copier les méthodes depuis TemplateEngine_additions.ts

# 6. Ajouter le beat sync dans FullscreenCreator.tsx
# Copier le code depuis FullscreenCreator_audio_analyser.tsx
```

---

## 🏗️ Architecture Détaillée

### Timeline Structure

```
┌─────────────────────────────────────────────────────────────┐
│  INTRO (0s → 1.6s)                                          │
│  ├─ Background vidéo + Ken Burns                            │
│  ├─ Warm glow + vignette                                    │
│  ├─ Sparkles commencent                                     │
│  ├─ InkMark apparaît (spring)                               │
│  └─ Texte "2026" + messages (blur-fade in)                  │
├─────────────────────────────────────────────────────────────┤
│  MAIN (1.6s → 12.8s)                                        │
│  ├─ Texte INTRO fade out                                    │
│  ├─ Texte MAIN fade in avec float loop                      │
│  ├─ Cheval entre et traverse (1.2s→15s)                     │
│  ├─ Beat sync actif sur tous éléments                       │
│  └─ Ken Burns continue                                      │
├─────────────────────────────────────────────────────────────┤
│  OUTRO (12.8s → 15s)                                        │
│  ├─ Texte MAIN fade out                                     │
│  ├─ Carte "Prêt à publier?" (breathe)                       │
│  ├─ Tous effets persistent                                  │
│  └─ Progress bar → 100%                                     │
└─────────────────────────────────────────────────────────────┘
```

### Layers Z-Index

```
Z-1   : Background vidéo (user_media_layer)
Z-2   : Gradients (warm glow, vignette)
Z-3   : Beat glow overlay
Z-5   : Sparkles particles
Z-7   : Horse silhouette
Z-8   : InkMark badge
Z-10  : Textes temporisés (year + messages)
Z-12  : Outro card
Z-15  : Progress bar + template label
```

---

## ✨ Nouvelles Fonctionnalités

### 1. Particle Layer (Sparkles)

```json
{
  "type": "particle_layer",
  "particles": {
    "count": 16,
    "area": { "x": [8, 48], "y": [10, 50] },
    "size": [2, 5],
    "color": "rgba(255,255,255,0.7)",
    "animation": "pulse-float",
    "duration": [1.2, 3.0],
    "shadow": "0 0 10px rgba(255,255,255,0.35)"
  }
}
```

**Rendu** : `renderParticleLayer()` dans `TemplateEngine.ts`

### 2. Composite Layer (Containers)

```json
{
  "type": "composite_layer",
  "children": [
    { "type": "shape_layer", "shape": "circle", "color": "rgba(0,0,0,0.35)" },
    { "type": "text_layer", "text": "祝你", "style": "calligraphy_main" }
  ],
  "container": {
    "padding": [12, 16],
    "background": "rgba(0,0,0,0.25)",
    "borderRadius": 16,
    "backdropBlur": 12
  }
}
```

**Rendu** : `renderCompositeLayer()` dans `TemplateEngine.ts`

### 3. SVG Layer (Cheval)

```json
{
  "type": "svg_layer",
  "asset": "horse_silhouette.svg",
  "size": { "width": 192, "height": 96 },
  "animation": {
    "loop": {
      "type": "traverse",
      "from": { "x": "110%" },
      "to": { "x": "-110%" },
      "duration": 11.3
    },
    "secondary": {
      "type": "float",
      "y": [-4, 0],
      "duration": 0.55
    }
  },
  "beatSync": {
    "enabled": true,
    "scale": [1.0, 1.03]
  }
}
```

**Rendu** : `renderSVGLayer()` dans `TemplateEngine.ts`

### 4. Gradient Layer (Glows)

```json
{
  "type": "gradient_layer",
  "gradient": {
    "type": "radial",
    "colors": ["rgba(255,210,120,0.35)", "rgba(0,0,0,0)"],
    "center": [26, 18],
    "radius": [60, 50]
  },
  "blend": "overlay",
  "beatSync": {
    "enabled": true,
    "opacity": [0.12, 0.55]
  }
}
```

**Rendu** : `renderGradientLayer()` dans `TemplateEngine.ts`

### 5. Progress Layer

```json
{
  "type": "progress_layer",
  "position": { "x": 20, "y": 16, "anchor": "bottom-left", "width": "calc(100% - 40px)" },
  "style": {
    "height": 6,
    "background": "rgba(255,255,255,0.1)",
    "fill": "rgba(255,255,255,0.7)",
    "borderRadius": 3
  }
}
```

**Rendu** : `renderProgressLayer()` dans `TemplateEngine.ts`

### 6. Beat Sync Audio

**Analyse** : Web Audio API (fréquences 0.02-0.22)  
**Normalisation** : `(avg - 25) / 130`  
**Application** : scale, opacity, glow sur layers avec `beatSync.enabled: true`

**Code** : `FullscreenCreator_audio_analyser.tsx`

---

## 🔧 Implémentation Technique

### Étape 1 : Ajouter les Renderers dans TemplateEngine.ts

```typescript
// Copier toutes les méthodes depuis TemplateEngine_additions.ts

private renderParticleLayer(layer: any, ctx: CanvasRenderingContext2D, now: number) { ... }
private renderCompositeLayer(layer: any, ctx: CanvasRenderingContext2D, now: number) { ... }
private renderSVGLayer(layer: any, ctx: CanvasRenderingContext2D, now: number) { ... }
private renderGradientLayer(layer: any, ctx: CanvasRenderingContext2D) { ... }
private renderProgressLayer(layer: any, ctx: CanvasRenderingContext2D) { ... }
```

### Étape 2 : Mettre à jour renderFrameToCanvas()

Dans le switch des layer types :

```typescript
case 'particle_layer':
  this.renderParticleLayer(layer, ctx, this.currentTime);
  break;
case 'composite_layer':
  this.renderCompositeLayer(layer, ctx, this.currentTime);
  break;
case 'svg_layer':
  await this.renderSVGLayer(layer, ctx, this.currentTime);
  break;
case 'gradient_layer':
  this.renderGradientLayer(layer, ctx);
  break;
case 'progress_layer':
  this.renderProgressLayer(layer, ctx);
  break;
```

### Étape 3 : Ajouter l'Audio Analyser dans FullscreenCreator.tsx

```typescript
// 1. Ajouter les refs
const audioContextRef = useRef<AudioContext | null>(null);
const audioAnalyserRef = useRef<AnalyserNode | null>(null);

// 2. Ajouter les fonctions
const setupAudioAnalyser = useCallback((audioElement: HTMLAudioElement) => { ... });
const cleanupAudioAnalyser = useCallback(() => { ... });

// 3. Intégrer dans le Golden Path
if (templateId === 'one_take_pro') {
  // ... existing code ...
  setupAudioForBeatSync(); // Nouvelle fonction
}
```

### Étape 4 : Mettre à jour AdvancedTemplateData.ts

Remplacer l'entrée `one_take_pro` avec le contenu de `AdvancedTemplateData_one_take_pro.ts`.

---

## 🐛 Troubleshooting

### Problème : Les sparkles ne s'affichent pas

**Solution** :
1. Vérifier que `renderParticleLayer()` est appelé
2. Vérifier le z-index (doit être 5)
3. Activer le debug : `console.log()` dans la méthode

### Problème : Le cheval ne bouge pas

**Solution** :
1. Vérifier que le SVG est chargé : `/templates/assets/svg/horse_silhouette.svg`
2. Vérifier l'animation traverse dans le manifest
3. Tester avec un z-index plus élevé temporairement

### Problème : Le beat sync ne fonctionne pas

**Solution** :
1. Vérifier que l'audio est chargé et joue
2. Vérifier la console pour les erreurs Web Audio
3. Activer `<AudioEnergyDebug />` pour voir l'énergie
4. Vérifier que `kEngine.setAudioEnergy()` est appelé
5. Cliquer sur le bouton "Activer le beat sync" si autoplay bloqué

### Problème : Les textes ne s'affichent pas

**Solution** :
1. Vérifier que tous les `.style.json` sont dans `public/templates/packs/textStyles/`
2. Vérifier les références de style dans le manifest
3. Vérifier les timings (start/end) des layers text

### Problème : Performance lente

**Solution** :
1. Réduire `fftSize` de l'analyser : `1024 → 512`
2. Réduire le nombre de sparkles : `16 → 8`
3. Désactiver beat sync sur mobile si nécessaire

---

## 📊 Checklist de Validation

- [ ] ✅ Tous les fichiers JSON copiés
- [ ] ✅ SVG du cheval accessible
- [ ] ✅ Styles de texte chargés (pas de 404)
- [ ] ✅ TemplateEngine.ts mis à jour
- [ ] ✅ FullscreenCreator.tsx mis à jour
- [ ] ✅ AdvancedTemplateData.ts mis à jour
- [ ] ✅ index.json mis à jour
- [ ] ✅ Sparkles visibles
- [ ] ✅ Cheval traverse l'écran
- [ ] ✅ InkMark badge animé
- [ ] ✅ Phases intro/main/outro fonctionnelles
- [ ] ✅ Progress bar se remplit
- [ ] ✅ Beat sync actif avec audio
- [ ] ✅ Ken Burns visible sur background
- [ ] ✅ Transitions fluides

---

## 🎨 Personnalisation

### Changer les Couleurs

Dans `one_take_pro_enhanced.json`, modifier :

```json
"gradient": {
  "colors": ["rgba(255,210,120,0.35)", "rgba(0,0,0,0)"]
}
```

### Changer les Textes

Dans `AdvancedTemplateData_one_take_pro.ts`, modifier :

```typescript
voiceInstructions: [
  { text_fr: 'Votre texte ici', text_ba: 'Texte en Bambara' }
]
```

### Changer la Durée

Dans `one_take_pro_enhanced.json`, modifier :

```json
"duration": 20,  // Au lieu de 15
```

Puis ajuster les timings des layers en conséquence.

### Ajouter des Effets

Créer un nouveau layer dans `timeline` :

```json
{
  "id": "mon_effet",
  "type": "gradient_layer",
  "zIndex": 4,
  "start": 0,
  "end": 20,
  "gradient": { ... }
}
```

---

## 📚 Ressources Complémentaires

- **DEPLOYMENT_GUIDE.md** : Guide détaillé de déploiement
- **TIMELINE_VISUAL.txt** : Schéma ASCII de la timeline
- **TemplateEngine_additions.ts** : Code complet des renderers
- **FullscreenCreator_audio_analyser.tsx** : Code complet beat sync

---

## 🎯 Résultat Attendu

Un template vidéo de **15 secondes** avec :

1. ✨ Background vidéo stabilisé avec Ken Burns
2. 📜 Calligraphie animée en haut-gauche (ink splashes)
3. ⭐ 16 sparkles scintillants
4. 🐴 Cheval qui traverse l'écran en boucle
5. 📝 Texte "2026" + messages avec contours blancs
6. 🎵 Beat sync subtil si musique ajoutée
7. 📊 Progress bar animée
8. 🎬 Transitions intro → main → outro fluides

---

## 🚀 Prochaines Étapes

1. Exécuter `npm run dev`
2. Ouvrir le Creator
3. Sélectionner "One-Take Pro Enhanced"
4. Filmer une vidéo (ou charger depuis galerie)
5. (Optionnel) Ajouter une musique pour le beat sync
6. Voir la magie opérer ! ✨

---

## 📝 Notes Finales

Ce template combine les meilleurs éléments de :
- **Kuaishou** : calligraphie, warm glow, phases temporisées
- **One-Take Pro** : stabilisation, qualité professionnelle
- **AI-Edit** : animations fluides, effets visuels riches

Tous les effets sont optimisés pour mobile et desktop, avec fallbacks pour l'autoplay audio et gestion intelligente de la performance.

---

**Version** : 2.0.0  
**Durée** : 15s  
**Ratio** : 9:16  
**Beat Sync** : ✅  
**Mobile Ready** : ✅  

---

🎬 **Bon développement !**
